
# TDM2 ALR

# Membre de Binome
- HAMRANI Khaled
- TRAN Quang Toan

# Structure de notre travail
| exercice1.sh
| exercice2.sh
| exercice3.sh
| Cyrano.txt
| bano-59009.csv
| html 
|    |--> contact.html
|    |--> fil.html

# Pour lancer
`bash exercice1.sh`
`bash exercice2.sh`
`bash exercice3.sh`
ou
`./exercice1.sh`
`./exercice2.sh`
`./exercice3.sh`
